module.exports = (c, client, handler) => {
    console.log(`🛜  ${client.user.tag} is online 🛜`);
};